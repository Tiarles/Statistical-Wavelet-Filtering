name = "statsWaveletFiltr"
__all__ = ['filtration', 'cusum', 'threshold', 'signals', 'misc']